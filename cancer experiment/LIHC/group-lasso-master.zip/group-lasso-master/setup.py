from setuptools import find_packages, setup

with open("README.rst") as f:
    long_description = f.read()


setup()
